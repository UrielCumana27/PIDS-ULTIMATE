// Actualizar año en el footer
document.addEventListener("DOMContentLoaded", () => {
    const yearSpan = document.getElementById('copyYear');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    // Botón de accesibilidad A+
    const btn = document.getElementById('btnA11y');
    if (btn) {
        btn.addEventListener('click', () => {
            document.body.classList.toggle('pids-a11y-on');
        });
    }
});

// ===== Quiz interactivo mejorado con reintentar =====
document.addEventListener('DOMContentLoaded', function() {
    const btnResultado = document.getElementById('btnVerResultado');
    const btnReintentar = document.getElementById('btnReintentar');
    const resultadoFinal = document.getElementById('resultadoFinal');

    if (!btnResultado || !btnReintentar) return; // Página sin actividades


    // ===== Mostrar resultado =====
    btnResultado.addEventListener('click', function() {
        const actividades = document.querySelectorAll('.actividad-item');
        let aciertos = 0;

        actividades.forEach((actividad, i) => {
            const radios = document.getElementsByName('respuesta_' + i);
            const correcta = document.getElementById('correcta_' + i).value;
            let elegida = null;

            // Buscar elegida
            for (const r of radios) {
                if (r.checked) {
                    elegida = r;
                    break;
                }
            }

            const feedback = document.getElementById('feedback_' + i);
            const opciones = actividad.querySelectorAll("input[type='radio']");
            const explicacion = document.getElementById('explicacion_' + i);

            // Reset clases previas
            opciones.forEach(o => {
                o.parentElement.classList.remove('correcta', 'incorrecta');
            });
            if (explicacion) {
                explicacion.style.display = 'none';
            }

            // Obtener texto completo de la opción correcta
            let textoCorrecta = "";
            opciones.forEach(o => {
                if (o.value === correcta) {
                    textoCorrecta = o.parentElement.textContent.trim();
                }
            });

            // Caso correcto
            if (elegida && elegida.value === correcta) {
            const textoElegida = elegida.parentElement.textContent.trim();

            feedback.textContent = '✅ ¡Muy bien! Respuesta correcta: ' + textoElegida;
            feedback.style.color = '#64FFDA';
            elegida.parentElement.classList.add('correcta');
            aciertos++;

            // No mostrar explicación en caso de respuesta correcta
            if (explicacion) {
            explicacion.style.display = 'none';
            }

            // No respondió
            } else if (!elegida) {
            feedback.textContent = '⚠️ Aún no respondes esta pregunta.';
            feedback.style.color = '#FFD166';

            // No mostrar explicación en caso de no haber respondido
            if (explicacion) {
            explicacion.style.display = 'none';
            }

            // Incorrecto
            } else {
            feedback.textContent = '❌ No es correcto. La respuesta correcta es: ' + textoCorrecta;
            feedback.style.color = '#FF6B6B';

            elegida.parentElement.classList.add('incorrecta');

            opciones.forEach(o => {
            if (o.value === correcta) {
            o.parentElement.classList.add('correcta');
            }
    });

    // Solo mostrar la explicación si la respuesta es incorrecta
    if (explicacion) {
        explicacion.style.display = 'block';
    }
}
        });

        // Mostrar resultado final
        resultadoFinal.textContent = `Tu resultado: ${aciertos} de ${actividades.length} correctas`;

        // Cambiar botones
        btnResultado.style.display = "none";
        btnReintentar.style.display = "inline-block";
    });


    // ===== Reiniciar todo =====
    btnReintentar.addEventListener('click', function() {
        const actividades = document.querySelectorAll('.actividad-item');

        actividades.forEach((actividad, i) => {
            const radios = document.getElementsByName('respuesta_' + i);
            const feedback = document.getElementById('feedback_' + i);
            const explicacion = document.getElementById('explicacion_' + i);

            radios.forEach(r => {
                r.checked = false;
                r.parentElement.classList.remove('correcta', 'incorrecta');
            });

            feedback.textContent = "";

            if (explicacion) {
                explicacion.style.display = 'none';
            }
        });

        resultadoFinal.textContent = "";

        // Cambiar botones
        btnReintentar.style.display = "none";
        btnResultado.style.display = "inline-block";
    });
});

// ===== Menú hamburguesa =====
const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("pidsNav");

if (menuToggle && nav) {
    menuToggle.addEventListener("click", () => {
        nav.classList.toggle("show");
    });
}
