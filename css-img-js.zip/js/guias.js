// Redireccion a la pagina de busqueda por guias
document.getElementById("btnInicio").addEventListener("click",
    function(){
        window.location.href="index.php";
    }
)

document.getElementById("logoInicio").addEventListener("click",
    function(){
        window.location.href="index.php";
    }
)

